#pragma once

#include <iostream>
#include <functional>
#include <cstdlib>
#include <fstream>
#include <string>
using namespace std;
class Ordena {
private:
	class Nodo
	{
	public:
		string titulo;
		Nodo* siguiente;
	};
	Nodo* primero;
public:
	Ordena() {}
	~Ordena() {}

	template <typename T>
	void intercambio(T* a, T* b)
	{
		T tmp = *a;
		*a = *b;
		*b = tmp;
	}

	template <typename ctd>
	void OrdenaminetoI(ctd conjunto[], int n) {
		int k, aux;
		for (int i = 1; i < n; i++) {
			aux = conjunto[i];
			k = i - 1;
			while (k >= 0 && aux < conjunto[k])
			{
				conjunto[k + 1] = conjunto[k];
				k--;
			}

			conjunto[k + 1] = aux;

			cout << endl;
			int p, q;
			for (p = 0; p <= i; p++) {
				cout << conjunto[p] << " ";
			}
			cout << " ^-^ ";

			for (q = p; q < n; q++)
			{
				cout << conjunto[q] << " ";
			}

			cout << endl;
		}
	}

	template <typename ctd>
	void impresionDatos(ctd codigo[], int n) {
		//impresion
		for (int i = 0; i < n; i++)
		{
			cout << codigo[i] << " ";
		}
	}

	void Principal() {
		int codigo[] = { 123, 890,432,923, 785, 645 };
		int n = sizeof(codigo) / sizeof(codigo[0]);
		OrdenaminetoI(codigo, n);
		cout << "\nCodigos de las canciones Ordenadas " << endl;
		impresionDatos(codigo, n);
		
		cout << endl; 
		system("pause"); 
	}
};