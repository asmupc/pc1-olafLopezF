#pragma once
using namespace std;
void CocktailSort(int a[], int n)
{
	bool cambiar = true;
	int inicio = 0;
	int final = n - 1;

	while (cambiar) {
		cambiar = false;
		for (int i = inicio; i < final; ++i) {
			if (a[i] > a[i + 1]) {
				swap(a[i], a[i + 1]);
				cambiar = true;
			}
		}

		if (!cambiar)
			break;

		cambiar = false;

		--final;

		for (int i = final - 1; i >= inicio; --i) {
			if (a[i] > a[i + 1]) {
				swap(a[i], a[i + 1]);
				cambiar = true;
			}
		}

		++inicio;
	}
}
void imprimircocktail(int a[], int n)
{
	for (int i = 0; i < n; i++)
		printf("%d ", a[i]);
	printf("\n");
}