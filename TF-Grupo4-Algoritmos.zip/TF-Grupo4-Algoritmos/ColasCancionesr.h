#pragma once

#include <iostream>
#include <functional>
#include <cstdlib>
#include <fstream>
#include <string>
using namespace std;
class Colasboleto
{
private:
	class Nodo {
	public:
		string due�o;
		Nodo* siguiente;
	};
	Nodo* primero;
	Nodo* ultimo;
public:
	Colasboleto();
	~Colasboleto();
	void insertar(string d);
	void extraer();
	void imprimir();
	bool vacia();
};

Colasboleto::Colasboleto()
{
	primero = nullptr;
	ultimo = nullptr;
}

Colasboleto::~Colasboleto()
{
	Nodo* reco = primero;
	Nodo* b;
	while (reco != nullptr)
	{
		b = reco;
		reco = reco->siguiente;
		delete b;
	}
}
void Colasboleto::insertar(string d) {
	Nodo* nuevo = new Nodo();
	nuevo->due�o = d;
	nuevo->siguiente = nullptr;
	if (vacia())
	{
		primero = nuevo;
		ultimo = nuevo;
	}
	else
	{
		ultimo->siguiente = nuevo;
		ultimo = nuevo;
	}
}
void Colasboleto::extraer() {
	if (!vacia())
	{
		string nombre = primero->due�o;
		Nodo* b = primero;
		if (primero == ultimo)
		{
			primero = nullptr;
			ultimo = nullptr;
		}
		else
		{
			primero = primero->siguiente;
		}
		delete b;
		cout << "la cancion " << nombre << " salio de la cola" << endl;
	}
	else
	{
		cout << "error" << endl;
	}
}
void Colasboleto::imprimir() {
	Nodo* reco = primero;
	cout << "listado de las canciones en la cola\n";
	while (reco != nullptr)
	{
		cout << reco->due�o << "-";
		reco = reco->siguiente;
	}
	cout << "\n";
	system("pause");
}
bool Colasboleto::vacia() {
	if (primero == nullptr)
	{
		return true;
	}
	else
	{
		return false;
	}
}
