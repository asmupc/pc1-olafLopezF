#include<iostream>
#include<vector>
#include <algorithm>
#include<random>
using namespace std;


struct node {
    int dato;
    node* siguiente;
};


struct node* create(int x)
{
    node* temporal = new node();
    temporal->dato = x;
    temporal->siguiente = nullptr;

    return temporal;
}


void insert(node*& cabeza, int n)
{
    if (cabeza == nullptr) {
        cabeza = create(n);
        return;
    }

    node* t = cabeza;
    while (t->siguiente != nullptr)
        t = t->siguiente;
    t->siguiente = create(n);
}


int del(node*& cabeza)
{
    if (cabeza == nullptr)
        return 0;
    node* temporal = cabeza;
   
    int val = cabeza->dato;

    
    cabeza = cabeza->siguiente;

    delete temporal;
    return val;
}


int digitos(int n)
{
    int i = 1;
    if (n < 10)
        return 1;

    while (n > (int)pow(10, i))
        i++;
    return i;
}

void radix_sort(vector<int>& arr)
{
    
    int sz = arr.size();

    
    int maximovalor = *max_element(arr.begin(), arr.end());

    
    int d = digitos(maximovalor);

    
    node** bins;

   

    bins = new node * [10];

   
    for (int i = 0; i < 10; i++)
        bins[i] = NULL;


    for (int i = 0; i < d; i++) {
        for (int j = 0; j < sz; j++) 
            insert(bins[(arr[j] / (int)pow(10, i)) % 10],
                arr[j]);

        int x = 0, y = 0;


        while (x < 10) {
            while (bins[x] != NULL)
                arr[y++] = del(bins[x]);
            x++;
        }
    }
}
void imprimirradix(vector<int> arr)
{
    for (int i = 0; i < arr.size(); i++)
        cout << arr[i] << " ";
    cout << endl;
}

void csvordenado(vector<int> arr) {
    ofstream ordenado;
    ordenado.open("baseordenado.csv");
    ordenado << "seguidores" << "\n";
    for (int i = 0; i < arr.size(); i++)
    {
        ordenado << to_string(arr[i]) << "\n";
    }
    ordenado.close();
}

