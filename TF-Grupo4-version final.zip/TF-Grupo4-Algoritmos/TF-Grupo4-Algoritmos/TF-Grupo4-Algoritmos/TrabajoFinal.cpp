#include <iostream>
#include <fstream>
#include <sstream>
#include <Windows.h>
#include <random>
#include <time.h>
#include "Controlador.h"
#include "ColasCancionesr.h"
#include "Historial.h"
#include "Ordenamiento.h"
#include "HashTable.h"
#include "ArbolB.h"
#include "CockTailSort.h"
#include "RadixSort.h"
#include "CountingSort.h"

HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
using namespace std;
///////////////IMPLEMENTACION DEL DATA SET(CREACION DE NUMEROS Y PALABRAS ALEATORIAS)
//hacemos que las palabras creadas tengas mas sentido al varias entre vocal y consonante al momento de su creacion
int numero() {
	int a;
	a = 5 + rand() % (10 - 5);
	return a;
}

char elegirconsonante(int n) {

	switch (n)
	{
	case 1: return char(98); break;
	case 2: return char(99); break;
	case 3: return char(100); break;
	case 4: return char(102); break;
	case 5: return char(103); break;
	case 6: return char(104); break;
	case 7: return char(106); break;
	case 8: return char(107); break;
	case 9: return char(108); break;
	case 10: return char(109); break;
	case 11: return char(110); break;
	case 12: return char(112); break;
	case 13: return char(113); break;
	case 14: return char(114); break;
	case 15: return char(115); break;
	case 16: return char(116); break;
	case 17: return char(118); break;
	case 18: return char(119); break;
	case 19: return char(120); break;
	case 20: return char(121); break;
	case 21: return char(122); break;
	}

}
char elegirvocal(int n)
{
	switch (n)
	{
	case 1: return char(97); break;
	case 2: return char(101); break;
	case 3: return char(105); break;
	case 4: return char(111); break;
	case 5: return char(117); break;
	}
}

string crearnombres() {
	char a;
	string b;
	int y = 0;
	int x = 0;
	int m = 1 + rand() % (2 - 1);
	bool nombre = true;

		for (int i = 0; i < numero(); i++)
		{
			x = 1 + rand() % (21 - 1);
			y = 1 + rand() % (5 - 1);

			if (nombre == true) {
				b += elegirconsonante(x);
				nombre = false;
			}
			else
			{
				b += elegirvocal(y);
				nombre = true;
			}
		}
		return b;
}

void creardatos() {
	int valor = 0;
	int creacion;
	ofstream KPrograma;
	KPrograma.open("basedata.csv");
	random_device rd;
	mt19937 eng(rd());
	uniform_int_distribution<int> dist(100, 12000);
	KPrograma << "seguidores" << ";" << "artistas" << "\n";
	cout << "cuantos valores quieres crear:"; cin >> creacion;
	for (size_t i = 0; i < creacion; ++i)
	{
		valor = dist(eng);
		KPrograma << to_string(valor) << ";" << crearnombres() << "\n";
	}
}
////////////////////////////////////////////
void imprimir(int e) {
	cout << e << " ";
}

////////////////////////////////////el menu de opciones que se muestra en el programa

int menu() {
	int x;
	SetConsoleTextAttribute(hConsole, 6);
	system("cls");
	cout << "\t------ BIENVENIDO AL MENU DE PLAYLIST -------" << endl << endl;
	SetConsoleTextAttribute(hConsole, 3);
	cout << "\t1. Agregar Playlist " << endl;
	cout << "\t2. Ver Playlist" << endl;
	cout << "\t3. Buscar Playlist" << endl;
	cout << "\t4. Modificar Playlist" << endl;
	cout << "\t5. Eliminar Playlist" << endl;
	cout << "\t6. Entrar a la cola de los boletos" << endl;
	cout << "\t7. Mostrar las personas de la cola" << endl;
	cout << "\t8. Revisar la cola" << endl;
	cout << "\t9. Revisar el historial de acciones" << endl;
	cout << "\t10 Quitar un registro del historial" << endl;
	cout << "\t11.Ordenar musicas por su codigo" << endl;
	cout << "\t12.ingresar datos a hashtable manualmente" << endl;
	cout << "\t13.imprimir el hash table" << endl;
	cout << "\t14.crear base de datos aleatorio en archivo .csv" << endl;
	cout << "\t15.meter datos de seguidores al hashtable" << endl;
	cout << "\t16.ingresar datos de seguidores al arbol binario" << endl;
	cout << "\t17.imprimir arbol EnOrden/postOrden/preOrden" << endl;
	cout << "\t18.ordenar los seguidores por CockTailSort(crea un dataset ordenado)" << endl;
	cout << "\t19.ordenar los seguidores por RadixSort(crea un dataset ordenado)" << endl;
	cout << "\t20.ordenar los seguidores por CountingSort(crea un dataset ordenado)" << endl;
	cout << "\t21.Salir" << endl;
	cout << "\tEliga una opcion: ";
	cin >> x;

	cout << endl;
	return x;
}
//////////////////////////////////////////////////////////

void print(int e) {
	cout << e << " ";
}

int main() {
	srand(time(NULL));
	ofstream Archivo;
	ifstream lectura;
	Musica* mus = new Musica();
	Colasboleto* cola = new Colasboleto();
	string duenios;
	Pila* P = new Pila();
	string histo;
	Ordena* o = new Ordena();
	CHashTable* ht = new CHashTable(10);
	ArbolBinario<int>* seguidoresarbol = new ArbolBinario<int>(print);
	int llave;
	string datos, linea;
	char delimitador = ';';
	int opc;
	do
	{
		system("cls");
		opc = menu();

		switch (opc)
		{
		case 1:
			SetConsoleTextAttribute(hConsole, 5);
			mus->agregarPlaylist(Archivo);
			P->insertar("agregar playlist");
			break;
		case 2:
			SetConsoleTextAttribute(hConsole, 9);
			mus->VerPlaylist(lectura);
			P->insertar("ver playlist");
			break;
		case 3:
			SetConsoleTextAttribute(hConsole, 6);
			mus->buscarPlaylist(lectura);
			P->insertar("buscar playlist");
			break;
		case 4:
			SetConsoleTextAttribute(hConsole, 3);
			mus->ModificarPlaylist(lectura);
			P->insertar("modificar playlist");
			break;
		case 5:
			SetConsoleTextAttribute(hConsole, 2);
			mus->eliminarCancion(lectura);
			P->insertar("eliminar playlist");
			break;
		case 6:
			system("cls");
			cout << "ingrese el nombre de la cancion que entrara la cola: ";
			cin >> duenios;
			cola->insertar(duenios);
			P->insertar("ingreso cancion a una cola");
			break;
		case 7:
			system("cls");
			cola->imprimir();
			P->insertar("imprimio la cola");
			break;
		case 8:
			system("cls");
			cola->extraer();
			P->insertar("actualizo la cola");
			system("pause");
			break;
		case 9:
			system("cls");
			P->insertar("reviso el historial");
			P->imprimir();
			system("pause");
			break;
		case 10:
			system("cls");
			P->extraer();
			P->insertar("quito un registro del historial");
			break;
		case 11:
			system("cls");
			o->Principal();
			break;
		case 12:
			system("cls");
			cout << "ingresa el numero de seguidores:"; cin >> llave;
			cout << "ingrelsa el nombre del cantante :"; cin >> datos;
			ht->insetar(CNodoHash(llave, datos));
			break;
		case 13:
			system("cls");
			cout << "TABLA HASH:\n";
			ht->imprimirtablacompleta();
			system("pause");
			break;
		case 14:
			system("cls");
			creardatos();
			cout << "base de datos aleatoria creada" << endl;
			system("pause");
			break;
		case 15: {
			system("cls");
			ifstream scv("basedata.csv");
			getline(scv, linea);
			while (getline(scv, linea))
			{
				stringstream stream(linea);
				string autor, seguidores; int seguidorenumero;
				getline(stream, seguidores, delimitador);
				getline(stream, autor, delimitador);
				seguidorenumero = stoi(seguidores);
				ht->insetar(CNodoHash(seguidorenumero, autor));
			}
			scv.close();
			cout << "datos ingresados al hashtable" << endl;
			system("pause");
			break; }
		case 16: {
			system("cls");
			ifstream scv("basedata.csv");
			getline(scv, linea);
			while (getline(scv, linea))
			{
				stringstream stream(linea);
				string autor, seguidores; int seguidorenumero;
				getline(stream, seguidores, delimitador);
				getline(stream, autor, delimitador);
				seguidorenumero = stoi(seguidores);
				seguidoresarbol->Insertar(seguidorenumero);
			}
			scv.close();
			cout << "datos ingresados al arbol" << endl;
			system("pause");
			break; }
		case 17:
			system("cls");
			cout << "EnOrden:"; seguidoresarbol->EnOrden(); cout << "\n";
			cout << "PreOrden:"; seguidoresarbol->PreOrden(); cout << "\n";
			cout << "PostOrden:"; seguidoresarbol->PostOrden(); cout << "\n";
			system("pause");
			break;
		case 18: {
			system("cls");
			int vectorseguidores[10];
			int m = 0;

			ifstream scv("basedata.csv");
			getline(scv, linea);
			while (getline(scv, linea))
			{
				stringstream stream(linea);
				string autor, seguidores; int seguidorenumero;
				getline(stream, seguidores, delimitador);
				getline(stream, autor, delimitador);
				seguidorenumero = stoi(seguidores);
				vectorseguidores[m] = seguidorenumero;
				m++;
			}
			int n = sizeof(vectorseguidores) / sizeof(vectorseguidores[0]);
			cout << "numero de seguidores desordenados: \n";
			imprimircocktail(vectorseguidores, n);
			cout << endl;
			CocktailSort(vectorseguidores, n);
			cout << "numero de seguidores ordenados: \n";
			imprimircocktail(vectorseguidores, n);
			csvordenado(vectorseguidores,n);
			scv.close();
			cout << "\n";
			system("pause");
			break; }
		case 19: {
			system("cls");
			vector<int> arr;
			vector<string> arr2;
			ifstream scv("basedata.csv");
			getline(scv, linea);
			while (getline(scv, linea))
			{
				stringstream stream(linea);
				string autor, seguidores; int seguidorenumero;
				getline(stream, seguidores, delimitador);
				getline(stream, autor, delimitador);
				seguidorenumero = stoi(seguidores);
				arr.push_back(seguidorenumero);
				arr2.push_back(autor);
			}
			cout << "numero de seguidores desordenados: \n";

			imprimirradix(arr);
			cout << endl;
			radix_sort(arr);
			cout << "numero de seguidores ordenados: \n";

			imprimirradix(arr);
			csvordenado(arr);
			scv.close();
			cout << "\n";
			system("pause");
			break; }

		case 20: {
			system("cls");
			vector<int> arr;
			ifstream scv("basedata.csv");
			getline(scv, linea);
			while (getline(scv, linea))
			{
				stringstream stream(linea);
				string autor, seguidores; int seguidorenumero;
				getline(stream, seguidores, delimitador);
				getline(stream, autor, delimitador);
				seguidorenumero = stoi(seguidores);
				arr.push_back(seguidorenumero);
			}
			cout << "numero de seguidores desordenados: \n";
			imprimirCounting(arr);
			countSort(arr);
			cout << endl;
			cout << "numero de seguidores ordenados: \n";
			imprimirCounting(arr);
			csvordenadocounting(arr);
			scv.close();
			cout << "\n";
			system("pause");
			break; }
		}
	} while (opc != 21);

	return 0;

}


