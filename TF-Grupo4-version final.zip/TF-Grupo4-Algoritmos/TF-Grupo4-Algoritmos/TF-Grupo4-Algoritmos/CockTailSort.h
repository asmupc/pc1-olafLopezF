#pragma once
using namespace std;
//implementacion del ordenamiento cocktail sort 
//este ordenamiento solo se puede max 10 ya que es un ordenamiento de valor constante
//ademas se le agrega una funcion para imprimir un dataset con los numeros ya ordenados
void CocktailSort(int a[], int n)
{
	bool cambiar = true;
	int inicio = 0;
	int final = n - 1;

	while (cambiar) {
		cambiar = false;
		for (int i = inicio; i < final; ++i) {
			if (a[i] > a[i + 1]) {
				swap(a[i], a[i + 1]);
				cambiar = true;
			}
		}

		if (!cambiar)
			break;

		cambiar = false;

		--final;

		for (int i = final - 1; i >= inicio; --i) {
			if (a[i] > a[i + 1]) {
				swap(a[i], a[i + 1]);
				cambiar = true;
			}
		}

		++inicio;
	}
}
void imprimircocktail(int a[], int n)
{
	for (int i = 0; i < n; i++)
		printf("%d ", a[i]);
	printf("\n");
}
void csvordenado(int a[],int n) {
	ofstream ordenado;
	ordenado.open("baseordenado.csv");
	ordenado << "seguidores" << "\n";
	for (int i = 0; i < n; i++)
	{
		ordenado << to_string(a[i]) << "\n";
	}
	ordenado.close();
}