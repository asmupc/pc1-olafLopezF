#pragma once
#include <algorithm>
#include <iostream>
#include <vector>
using namespace std;
//implementacion del ordenamiento counting sort
//este ordenamiento ordena cualquier numero de datos ya que esta implementado con vectores
//ademas se le agrega una funcion para imprimir un data set con los numeros ya ordenados
void countSort(vector<int>& arr)
{
    int maximo = *max_element(arr.begin(), arr.end());
    int minimo = *min_element(arr.begin(), arr.end());
    int range = maximo - minimo + 1;

    vector<int> count(range), output(arr.size());
    for (int i = 0; i < arr.size(); i++)
        count[arr[i] - minimo]++;

    for (int i = 1; i < count.size(); i++)
        count[i] += count[i - 1];

    for (int i = arr.size() - 1; i >= 0; i--) {
        output[count[arr[i] - minimo] - 1] = arr[i];
        count[arr[i] - minimo]--;
    }

    for (int i = 0; i < arr.size(); i++)
        arr[i] = output[i];
}

void imprimirCounting(vector<int>& arr)
{
    for (int i = 0; i < arr.size(); i++)
        cout << arr[i] << " ";
    cout << "\n";
}

void csvordenadocounting(vector<int> arr) {
    ofstream ordenado;
    ordenado.open("baseordenado.csv");
    ordenado << "seguidores" << "\n";
    for (int i = 0; i < arr.size(); i++)
    {
        ordenado << to_string(arr[i]) << "\n";
    }
    ordenado.close();
}