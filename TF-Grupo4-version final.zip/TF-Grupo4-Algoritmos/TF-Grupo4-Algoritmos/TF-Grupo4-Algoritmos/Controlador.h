#pragma once
#include <iostream>
#include "Musicas.h"
#include <vector>
#include <fstream>
#include <algorithm>


using namespace std; 
//implementacion de las funciones principales del manejo de archivos
struct Nbase {
	int dato;
	Nbase* siguiente;
};

template<class ti>
auto s1 = [](ti nombre, ti autor, ti cod) {
	return cod;
}

class Controlador
{
private: 
	ofstream salida;
	ifstream entrada;
	
	int borrado;
public:
	Controlador(){}
	~Controlador(){}

	Nbase* lista;
	void insertaMusica(int d) {
		Nbase* nodoNuevo = new Nbase();

		nodoNuevo->dato = d;
		Nbase* aux1 = lista;
		Nbase* aux2;

		while ((aux1 != nullptr) && (aux1->dato <= d))
		{
			aux2 = aux1;
			aux1 = aux1->siguiente;
		}

		if (aux1 == lista)
		{
			lista = nodoNuevo;
		}
		else {//verifica si hubo un nuevo elemento
			aux2->siguiente = nodoNuevo;
		}

		nodoNuevo->siguiente = aux1;
	}

	void imprimeMusicas() {
		Nbase* actual = new Nbase();
		actual = lista;

		while (actual != nullptr)
		{
			cout << actual->dato << " ";
			actual = actual->siguiente;
		}
	}

	void buscaMusica(int buscando) {
		bool resultado = false;
		Nbase* actual = new Nbase();
		actual = lista;

		while ((actual != nullptr) && (actual->dato <= buscando))
		{
			if (actual->dato == buscando) {
				resultado = true;
			}
			actual = actual->siguiente;
		}

		if (resultado == false) {
			cout << "Musica no encontrado";
		}
		else cout << "Elemento encontrado";
	}


	void eliminarMusica(int borrado) {
		if (lista != nullptr) {
			Nbase* Borrar;
			Nbase* anterior = nullptr;
			Borrar = lista;

			while ((Borrar != nullptr) && (Borrar->dato != borrado))
			{
				anterior = Borrar;
				Borrar = Borrar->siguiente;
			}

			if (Borrar == nullptr) {
				cout << "La musica no fue encontrada";
			}
			else if (anterior == nullptr) {
				lista = lista->siguiente;
				delete Borrar;
			}
			else {
				anterior->siguiente = Borrar->siguiente;
				delete Borrar;
			}
		}
	}


};

