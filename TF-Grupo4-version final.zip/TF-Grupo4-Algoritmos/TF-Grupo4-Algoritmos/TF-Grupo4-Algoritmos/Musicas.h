#pragma once
#include <iostream>
#include <functional>
#include <cstdlib>
#include <fstream>
#include <string>



using namespace std; 
//creacion de los archivos de usuario donde puedes poner los datos principales de las canciones y son guardadas en un archivo
//template<typename T>
struct Base
{
	string nombre; 
	string Autor; 
	int codigo; 
	Base* nueva;
};

class Musica
{
private: 
	string nom, aut; int cod; 
	string nmb, atr;
	int cdg;
	string nmbe, ator; 
	int cdgo, cdgAux;
	bool encontrado = false;

public:
	Musica(){}

	~Musica(){}

	void agregarPlaylist(ofstream& archivo) {
		system("cls");
		int tam=0; 
		archivo.open("Usuarios.txt", ios::out | ios::app);
		cout << "\t--- Bienvenido a tu Playslist ----" << endl;
		cout << "\tCancion: ";
		cin >> nom;
		cout << "\tAutor: ";
		cin >> aut;
	    cout << "\tCodigo de la cancion (que sea de tres digitos): ";
		cin >> cod;
		

		archivo << nom<<","<< aut << "," << cod<<"\n";
		archivo.close();
	}

	void VerPlaylist(ifstream &lectura) {
		system("cls");  
		lectura.open("Usuarios.txt", ios::in);
		if (lectura.is_open()) {
			
			cout << "\t<--- Registro de Musicas Guardadas ---->" << endl << endl;
			lectura >> nmb;
			while (!lectura.eof())
			{
				lectura >> atr;
				lectura >> cdg;
				cout << "Cancion: " << nmb << endl;
				cout << "Autor: " << atr << endl;
				cout << "Codigo: " << cdg << endl;
				cout << endl;
				lectura >> nmb;
			}
			lectura.close();
		}
		else {
			cout << "Error no se encontr� la musica" << endl;
		}
			 

		system("pause"); 
	}

	void buscarPlaylist(ifstream& lectura) {
		system("cls");
		lectura.open("Usuarios.txt", ios::in);

		cout << "Digite el codigo que desea encontrar: ";
		cin >> cdgAux;

		lectura >> nmbe;
		while (!lectura.eof() && !encontrado)
		{
			lectura >> ator;
			lectura >> cdgo;

			if (cdgo == cdgAux) {
				cout << "Cancion:" << nmbe << endl;
				cout << "Autor: " << ator << endl;
				cout << "Codigo: " << cdgo << endl;
				encontrado = true;
			}
			lectura >> nmbe;
		}
		lectura.close();

		if (!encontrado)
			cout << "La cancion que estas buscando no existe" << endl;

		cout << endl;
		system("pause");
	}

	void ModificarPlaylist(ifstream &lectura){
		system("cls");
		string n; 
		string a; 
		int c; 
		string nAux; string aAux; int cAux; 

		lectura.open("Usuarios.txt", ios::in); 
		ofstream aux("CarpetaAux.txt", ios::out);

		if (lectura.is_open())
		{
			cout << "Codigo: "; 
			cin >> cAux; 

			lectura >> n; 
			while(!lectura.eof()){
				lectura >> a; 
				lectura >> c; 

				if(c == cAux){
					cout << "Ingresa el nuevo nombre de la cancion: "; 
					cin >> nAux; 
					cout << "Ingresa el nuevo autor de la cancion: "; 
					cin >> aAux; 

					aux << nAux << " " << "\n" << aAux << "\n" << cAux << "\n" << "\n"; 
				}
				else {
					aux << n << " " << "\n" << a << "\n" << c << "\n" << "\n";
				}
				
				lectura >> n;
			}
			lectura.close(); 
			aux.close();
		}
		else {
			cout << "Error, no se pudo modificar la cancion" << endl;
		}
		remove("Usuarios.txt");
		rename("CarpetaAux.txt", "Usuarios.txt");
	}		

	void eliminarCancion(ifstream& lectura){
		system("cls");
		string n;
		string a;
		int c;
		string nAux; string aAux; int cAux;

		lectura.open("Usuarios.txt", ios::in);
		ofstream aux("CarpetaAux.txt", ios::out);

		if (lectura.is_open())
		{
			cout << "Codigo: ";
			cin >> cAux;

			lectura >> n;
			while (!lectura.eof()) {
				lectura >> a;
				lectura >> c;
					
				if (c == cAux) {
					cout << "Musica eliminado" << endl; 
					system("pause");
				}
				else {
					aux << n << " " << "\n" << a << "\n" << c << "\n" << "\n";
				}
				lectura >> n;
			}
			lectura.close();
			aux.close();
		}
		else
			cout << "Error, no se pudo eliminar la musica" << endl;
		remove("Usuarios.txt");
		rename("CarpetaAux.txt", "Usuarios.txt");

		system("pause"); 
	}

	
	void intercambio(int* a, int* b)
	{
		int tmp = *a;
		*a = *b;
		*b = tmp;
	}

	//void OrdBurbujaMejorado(ifstream&lectura) {
	//	int n = 10; 
	//	bool ordenados = false;
	//	string temp[50]; 

	//	lectura.open("Usuarios.txt", ios::in);
	//	lectura >> nmbe;
	//	while (!lectura.eof())
	//	{
	//		lectura >> ator;
	//		lectura >> cdgo;
 //           
	//		for (int i = 0; i < n; i++)
	//		{
	//			for (int j = i + 1; j < n; j++)
	//			{
	//				if (strcmp((nmbe[i], nmbe[j]) > 0)
	//				{
	//					strcpy(temp, nbme[i]); 
	//					strcpy(temp, nbme[i]);
	//						strcpy(temp, nbme[i]);
	//				}
	//			}
	//			if (ordenados == true) break; {

	//			}
	//			//mostrar los datos que est�n en la burbuja
	//			//mostrar los datos que estan fuera o aun desordenados
	//		}

	//			cout << "Cancion:" << nmbe << endl;
	//			cout << "Autor: " << ator << endl;
	//			cout << "Codigo: " << cdgo << endl;
	//			encontrado = true;
	//		
	//		lectura >> nmbe;
	//	}
	//	lectura.close();
	//}


};

