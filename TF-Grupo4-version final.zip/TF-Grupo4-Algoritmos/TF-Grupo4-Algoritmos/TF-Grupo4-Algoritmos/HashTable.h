#pragma once

#include <iostream>
#include <functional>
#include <cstdlib>
#include <fstream>
#include <string>
#include <list>
#include<vector>
using namespace std;
//implementacion de la clase hash table y la clase nodo del hash
class CNodoHash
{
private:
	int clave;
	string valor;
public:
	CNodoHash(int _clave, string _valor) {
		clave = _clave;
		valor = _valor;
	}
	int getClave() {
		return clave;
	}

	string getValor() {
		return valor;
	}

	void imprimir() {
		cout << "Clave:" << clave << " | Artista: " << valor << endl;
	}

};

class CHashTable {
private:
	vector<list<CNodoHash>> tabla;
	int cantElementos;
public:
	CHashTable(int tama�o) {
		cantElementos = 0;
		tabla.resize(tama�o);
	}
	void vaciar() {
		for (auto& sublista : tabla)
			sublista.clear();
	}

	size_t myhash(const int key) const {
		size_t hashVal = key;
		hashVal %= tabla.size();//formula hash
		return(hashVal);
	}
	bool insetar(CNodoHash&& x) {
		auto& whichList = tabla[myhash(x.getClave())];
		whichList.push_back(x);
		return true;
	}
	void imprimirtabla() {
		int pos = 0;
		for (auto& sublista : tabla) {
			cout << "Llave: " + to_string(pos) << " | ";
			for (auto& it : tabla[pos]) {
				cout << it.getClave() << ",";
			}
			cout << endl;
			pos++;
		}
	}
	void imprimirtablacompleta() {
		int pos = 0;
		for (auto& sublista : tabla) {
			cout << "Llave: " + to_string(pos) << " | ";
			for (auto& it : tabla[pos]) {
				it.imprimir();
			}
			cout << endl;
			pos++;
		}
	}
};
