#pragma once
#include "Musicas.h"
#include <fstream>

using namespace std; 
//pruebas de colas y pilas 
//lo dejamos aca como prueba del trabajo pero al ya haber implementado colas y pilas en el programa este .h no es importante
struct Nodo
{
	int dato; 
	Nodo* siguiente; 
};

struct Nodo
{
	string nom;
	string autor;
	int codigo; 
};

class PiCo
{
private: 
	Nodo* nuevo = new Nodo(); 
public:
	PiCo(){}
	~PiCo(){}

	/*void agregarPlaylist(ofstream& archivo) {
		system("cls");
		int tam = 0;
		archivo.open("Usuarios.txt", ios::out | ios::app);
		cout << "\t--- Bienvenido a tu Playslist ----" << endl;
		cout << "\tCancion: ";
		cin >> nuevo->nom;
		cout << "\tAutor: ";
		cin >> nuevo->autor;
		cout << "\tCodigo de la cancion (que sea de tres digitos): ";
		cin >> nuevo->codigo;


		archivo << nuevo->nom << "\n" << nuevo->autor << "\n" << nuevo->codigo << "\n\n";
		archivo.close();
	}
	
	void quitaPlaylist(ifstream& lectura) {
		Nodo*& tope; 
		int& n;
		Nodo* actual = tope; 
		n = actual->nom; 
		tope = actual->siguiente; 
		delete actual; 
	}

	void sacarPlaylist(Nodo*&nomN, Nodo*&autorN ) {

	}*/
};
