#pragma once
#include <iostream>
#include <functional>
#include <cstdlib>
#include <fstream>
#include <string>
//implementacion de las pilas en el programa con las principales funciones
using namespace std;
class Pila {
private:
	class Nodo
	{
	public:
		string titulo;
		Nodo* siguiente;
	};
	Nodo* primero;
public:
	Pila();
	~Pila();
	void insertar(string t);
	void extraer();
	void imprimir();
};
Pila::Pila() {
	primero = nullptr;
}
void Pila::insertar(string t) {
	Nodo* nuevo = new Nodo();
	nuevo->titulo = t;
	if (primero == nullptr)
	{
		primero = nuevo;
		nuevo->siguiente = nullptr;
	}
	else
	{
		nuevo->siguiente = primero;
		primero = nuevo;
	}
}
void Pila::imprimir() {
	Nodo* reco = primero;
	cout << "Historial de acciones en el programa:\n";
	cout << "\n";
	while (reco != nullptr)
	{
		cout << reco->titulo << endl;
		reco = reco->siguiente;
	}
	cout << "\n";
}
void Pila::extraer() {
	if (primero != nullptr)
	{
		string info = primero->titulo;
		Nodo* bor = primero;
		primero = primero->siguiente;
		delete bor;
		cout << info << endl;
	}
	else
	{
		cout << "ERROR" << endl;
	}
}
Pila::~Pila()
{
	Nodo* reco = primero;
	Nodo* b;
	while (reco != NULL)
	{
		b = reco;
		reco = reco->siguiente;
		delete b;
	}
}